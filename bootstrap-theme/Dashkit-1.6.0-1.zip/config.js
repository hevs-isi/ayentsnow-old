module.exports = {
  demoMode: false,
  colorScheme: 'light',
  navPosition: 'sidenav',
  navColor: 'default',
  sidebarSize: 'base'
};
